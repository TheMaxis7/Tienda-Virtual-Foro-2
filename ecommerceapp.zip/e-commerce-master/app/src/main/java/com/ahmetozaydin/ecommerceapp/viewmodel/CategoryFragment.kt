package com.ahmetozaydin.ecommerceapp.viewmodel

import androidx.lifecycle.ViewModel

class CategoryFragment : ViewModel(){

    fun getCategoriesFromAPI(){

    }
}